#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "boards.h"
#include "app_util_platform.h"
#include "app_error.h"
#include "nrf_drv_twi.h"
//#include "bsp.h"
#include "mpu6050.h"
#include "nrf_delay.h"



 
#include <string.h>
#include "nrf.h"
#include "nrf_drv_saadc.h"
#include "nrf_drv_ppi.h"
#include "nrf_drv_timer.h"
//#include "nrf_pwr_mgmt.h"
 

#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"
#include "arm_const_structs.h"

static float32_t acc_arr_x[128];
static float32_t acc_arr_y[128];
static float32_t acc_arr_z[128];

#define FFT_TEST_SAMPLE_FREQ_HZ          1000.0f                        //!< Frequency of complex input samples.
#define FFT_TEST_COMP_SAMPLES_LEN        128                             //!< Complex numbers input data array size. Correspond to FFT calculation this number must be power of two starting from 2^5 (2^4 pairs) with maximum value 2^13 (2^12 pairs).
#define FFT_TEST_OUT_SAMPLES_LEN         (FFT_TEST_COMP_SAMPLES_LEN / 2) //!< Output array size.

static uint32_t  m_ifft_flag             = 0;                            //!< Flag that selects forward (0) or inverse (1) transform.
static uint32_t  m_do_bit_reverse        = 1;                            //!< Flag that enables (1) or disables (0) bit reversal of output.
static float32_t m_fft_input_f32[FFT_TEST_COMP_SAMPLES_LEN];             //!< FFT input array. Time domain.
static float32_t m_fft_output_f32[FFT_TEST_OUT_SAMPLES_LEN];  
static int16_t AccValue[3], GyroValue[3];


const nrfx_timer_t TIMER_LED = NRFX_TIMER_INSTANCE(0); // Timer 0 Enabled
#define LED1 13
#define LED4 16
#define airlock 3
 
int16_t adc_buffer[300];
volatile uint16_t adc_cnt = 0, adc_flag=0,k=0;
uint32_t i2c_buffer[68];
uint8_t dummy_buffer[90];



void find_max(void)
{
 
int16_t max_value[55] = {0};
uint32_t avg=0;
 
for(int j =0 ; j<40;j++ )
{
for(int i = 0; i<20; i++)
{
if((adc_buffer[i+(j*20)])>max_value[j])
max_value[j] =adc_buffer[i+(j*20)];
}
 
avg = avg + max_value[j];
}
//NRF_LOG_RAW_INFO("%d",(((avg/50)-1730)*26));
m_fft_output_f32[64] = (((avg/40)-1700)*26);

//NRF_LOG_RAW_INFO("%d",(avg/40))
//NRF_LOG_RAW_INFO("\n");
 
}


void timer0_handler(nrf_timer_event_t event_type, void* p_context)
{
  switch(event_type)
  {
      case NRF_TIMER_EVENT_COMPARE0:
      if(adc_cnt < 201)
      nrfx_saadc_sample_convert(0, &adc_buffer[adc_cnt]);
      adc_cnt++;
      break;
 
      default:
      // Nothing
      break;
  }

 
}
 
 
 
void timer_init(void)
{
  uint32_t err_code = NRF_SUCCESS;
 
  uint32_t time_ms = 1;
 
  uint32_t time_ticks;
 
 
  nrfx_timer_config_t timer_cfg = NRFX_TIMER_DEFAULT_CONFIG; // Configure the timer instance to default settings
 
timer_cfg.bit_width = NRF_TIMER_BIT_WIDTH_32;
  err_code = nrfx_timer_init(&TIMER_LED, &timer_cfg, timer0_handler); // Initialize the timer0 with default settings
  APP_ERROR_CHECK(err_code); // check if any error occured
 
  time_ticks = nrfx_timer_ms_to_ticks(&TIMER_LED, time_ms); // convert ms to ticks
 
// Assign a channel, pass the number of ticks & enable interrupt
  nrfx_timer_extended_compare(&TIMER_LED, NRF_TIMER_CC_CHANNEL0, time_ticks, NRF_TIMER_SHORT_COMPARE0_CLEAR_MASK, true);
 
}
 
 
 
/* Create an empty handler and pass this handler in the saadc initialization function
> Normally this handler deals with the adc events but we are using blocking mode
> In blocking mode the functions are called and the processor waits for the adc to finish taking samples from the respective channels
> Event handler will not be called in this method
*/
 
void saadc_callback_handler(nrf_drv_saadc_evt_t const * p_event)
{
// Empty handler function
}
 
 
 
// Create a function which configures the adc input pins and channels as well as the mode of operation of adc
 
void saadc_init(void)
{
	// A variable to hold the error code
  ret_code_t err_code;
 
  // Create a config struct and assign it default values along with the Pin number for ADC Input
  // Configure the input as Single Ended(One Pin Reading)
  // Make sure you allocate the right pin.
  nrf_saadc_channel_config_t channel_config = NRFX_SAADC_DEFAULT_CHANNEL_CONFIG_SE(NRF_SAADC_INPUT_AIN2);
 
  // Initialize the saadc 
  // first parameter is for configuring the adc resolution and other features, we will see in future tutorial
  //on how to work with it. right now just pass a simple null value
  nrf_drv_saadc_config_t saadc_config = NRF_DRV_SAADC_DEFAULT_CONFIG;
  saadc_config.resolution = NRF_SAADC_RESOLUTION_12BIT;
 
err_code = nrf_drv_saadc_init(&saadc_config, saadc_callback_handler);
  //err_code = nrf_drv_saadc_init(NULL, saadc_callback_handler);
  APP_ERROR_CHECK(err_code);
 
// Initialize the Channel which will be connected to that specific pin.
  err_code = nrfx_saadc_channel_init(0, &channel_config);
  APP_ERROR_CHECK(err_code);
 
  
 
}
 
 


static void fft_process(float32_t *                   p_input,
                        const arm_cfft_instance_f32 * p_input_struct,
                        float32_t *                   p_output,
                        uint16_t                      output_size)
{
    // Use CFFT module to process the data.
    arm_cfft_f32(p_input_struct, p_input, m_ifft_flag, m_do_bit_reverse);
    // Calculate the magnitude at each bin using Complex Magnitude Module function.
    arm_cmplx_mag_f32(p_input, p_output, output_size);
}



void mpu_init(void)
{

    twi_master_init(); // initialize the twi 
    nrf_delay_ms(1000); // give some delay

    while(mpu6050_init() == false) // wait until MPU6050 sensor is successfully initialized
    {
      NRF_LOG_INFO("MPU_6050 initialization failed!!!"); // if it failed to initialize then print a message
      nrf_delay_ms(1000);
    }

   NRF_LOG_INFO("MPU6050 Init Successfully!!!"); 
   mpu6050_register_write(19, 0);
   NRF_LOG_INFO("Frequency Sampling : %d",MPU_SAMPLE_RATE_REG); 

   NRF_LOG_INFO("Reading Values from ACC & GYRO"); // display a message to let the user know that the device is starting to read the values
   nrf_delay_ms(1000);


}

void mpu_sense(void)
{
     
       for(int i=0;i<128;i++) 
       {  if(MPU6050_ReadAcc(&AccValue[0], &AccValue[1], &AccValue[2]) == true) // Read acc value from mpu6050 internal registers and save them in the array
           {   
            m_fft_input_f32[i] = AccValue[0];
           }
          else
           {
              NRF_LOG_INFO("Reading ACC values Failed!!!"); // if reading was unsuccessful then let the user know about it
           }

         nrf_delay_ms(1);
        }

        fft_process(m_fft_input_f32,
                    &arm_cfft_sR_f32_len64,
                    m_fft_output_f32,
                    FFT_TEST_OUT_SAMPLES_LEN); 
}

// main code


void collect_data(void)
{
       int16_t max_value[11] = {0};
       uint32_t avg=0;
       uint16_t current = 0;
       nrf_drv_timer_enable(&TIMER_LED);
       mpu_sense();
       for(int j =0 ; j<10;j++ )
         {
           for(int i = 0; i<20; i++)
              {
                if((adc_buffer[i+(j*20)])>max_value[j])
                max_value[j] =adc_buffer[i+(j*20)];
              }
             avg = avg + max_value[j];
         }

for(int i = 0; i< 64; i++)
{
if(m_fft_output_f32[i]>65530)
m_fft_output_f32[i]=65530;
i2c_buffer[i] = m_fft_output_f32[i];
}
current = (((avg/10)-1720)*26);   // current values

i2c_buffer[67] = 0;  //do stalling analysis

if(current>4000)
{ 
  i2c_buffer[67] = 1;  //do stalling analysis
}
if(nrf_gpio_pin_read(airlock) || current<2000)
i2c_buffer[65] = 0;  //digital read nicla and set accordingly
else
i2c_buffer[65] = 100;

i2c_buffer[66] = 0;  //do stability analysis

for (int x=50; x<64;x++)
{ if(m_fft_output_f32[x]>2500)
  i2c_buffer[66]=1;
}



i2c_buffer[64] = current;
//for(int j = 0; j< 68; j++)
//NRF_LOG_INFO("%d, ",i2c_buffer[j]);
//NRF_LOG_INFO("adc cnt value from collect data= %d", adc_cnt);
while(adc_cnt<400)
{
}
  //find_max();
}

void send_data_to_i2c(void)
{
       //write i2c code here
         //  send_data(i2c_buffer);
for(int i=0; i<68; i++)
NRF_LOG_RAW_INFO("%d\n ",i2c_buffer[i]);

//NRF_LOG_RAW_INFO("\n");
   // NRF_LOG_INFO("adc cnt value from send data = %d", adc_cnt);
    while(adc_cnt<900)
     {}
    adc_cnt=0;
    nrf_gpio_pin_toggle(13);
    nrf_drv_timer_disable(&TIMER_LED);
    nrf_gpio_pin_set(31);
    nrf_delay_ms(100);
nrf_gpio_pin_clear(31);
}


int main(void)
{

    APP_ERROR_CHECK(NRF_LOG_INIT(NULL));
    NRF_LOG_DEFAULT_BACKENDS_INIT();
    timer_init();
    saadc_init();
    mpu_init();
    nrf_gpio_cfg_output(13);
    nrf_gpio_cfg_output(31);
    nrf_gpio_cfg_input(airlock, NRF_GPIO_PIN_PULLDOWN);
       nrf_gpio_pin_clear(31);

    while (true)
    { 
           
             collect_data();

             send_data_to_i2c();

    }
}

/** @} */